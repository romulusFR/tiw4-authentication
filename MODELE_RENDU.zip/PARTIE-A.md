Rapport de la partie A
======================