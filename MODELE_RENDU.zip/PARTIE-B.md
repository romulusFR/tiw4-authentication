Rapport de la partie B
======================